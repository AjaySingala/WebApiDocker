import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { GridJoggingComponent } from './grid-jogging/grid-jogging.component';
import { AddOrUpdateJoggingComponent } from './add-or-update-jogging/add-or-update-jogging.component';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { WorkoutService } from './workout.service';
import { DecimalPipe } from '@angular/common';
import { DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { OktaAuthGuard, OktaAuthModule, OktaCallbackComponent, OKTA_CONFIG } from '@okta/okta-angular';
import { ProfileComponent } from './profile/profile.component';

const CALLBACK_PATH = 'login/callback';
const appRoutes: Routes = [
  {
    path: CALLBACK_PATH,
    component: OktaCallbackComponent
  },
  { path: 'home', component: HomeComponent, canActivate: [OktaAuthGuard] },
  { path: 'profile', component: ProfileComponent },
];

const oktaConfig = {
  issuer: 'https://dev-42327944.okta.com/oauth2/default',
  redirectUri: 'http://localhost:4200/login/callback',
  clientId: '0oatgsn49V853c47Y5d6',
    scopes: ['openid', 'profile', 'email'],
  pkce: true
};

// // Require authentication on every route except login callback route
// const pathExceptions = [
//   CALLBACK_PATH
// ];
// const protectedRoutes = appRoutes.filter(route => !pathExceptions.includes(route.path));
// protectedRoutes.forEach(route => {
//   router.canActivate = router.canActivate || [];
//   route.canActivate.push(OktaAuthGuard);
// });

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    GridJoggingComponent,
    AddOrUpdateJoggingComponent,
    ProfileComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(appRoutes),
    HttpClientModule,
    FormsModule,
    OktaAuthModule
  ],
  providers: [
    WorkoutService,
    {provide: OKTA_CONFIG, useValue: oktaConfig }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
