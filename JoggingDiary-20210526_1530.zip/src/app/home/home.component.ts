import { Identifiers } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { WorkoutService } from '../workout.service'

//import { OktaAuthService } from '@okta/okta-angular';

// Okta Domain: https://dev-42327944.okta.com/oauth2/default
// Okta Client Id: 0oatg15y28TTMFe3H5d6

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  public joggingData: Array<any>;
  public currentJogging: any;
  //public isAuthenticated: boolean = false;

  constructor(private workoutService: WorkoutService) {
    workoutService.get().subscribe((data: any) => this.joggingData = data);
    this.currentJogging = this.setInitialValuesForJoggingData();
    console.log('homecontroller');
    console.log(this.joggingData);
  }

  ngOnInit() {
  }

  private setInitialValuesForJoggingData() {
    return {
      id: undefined,
      date: '',
      distanceInMeters: 0,
      timeInSeconds: 0
    }
  }

  public createOrUpdateJogging(jogging: any) {
    let id = Math.floor(Math.random() * (9999 - 1 + 1) + 1);
    jogging.id = id;
    console.log(jogging);
    // if jogging is present in joggingData, we can assume this is an update
    // otherwise it is adding a new element
    let joggingWithId: any;
    //joggingWithId = _.find(this.joggingData, (el => el.id === jogging.id));
    joggingWithId = this.joggingData.find(el => el.id === jogging.id);
    console.log(joggingWithId);
    //console.log(joggingWithId.id);

    if (joggingWithId) {
      //const updateIndex = _.findIndex(this.joggingData, {id: joggingWithId.id});
      const updateIndex = this.joggingData.findIndex(idx => idx.id === joggingWithId.id);
      console.log(updateIndex);

      this.workoutService.update(jogging).subscribe(
        joggingRecord => this.joggingData.splice(updateIndex, 1, jogging)
      );
    } else {
      this.workoutService.add(jogging).subscribe(
        joggingRecord => this.joggingData.push(jogging)
      );
    }

    this.currentJogging = this.setInitialValuesForJoggingData();
  };

  public editClicked(record: any) {
    this.currentJogging = record;
  };

  public newClicked() {
    this.currentJogging = this.setInitialValuesForJoggingData();
  };

  public deleteClicked(record: any) {
    console.log("deleteClicked: deleteing id " + record.id)
    console.log(record);
    console.log(this.joggingData);
    //const deleteIndex = _.findIndex(this.joggingData, {id: record.id});
    const deleteIndex = this.joggingData.findIndex(idx => idx.id === record.id);
    console.log(deleteIndex);

    this.workoutService.remove(record).subscribe(
      result => this.joggingData.splice(deleteIndex, 1)
    );
  }
}
