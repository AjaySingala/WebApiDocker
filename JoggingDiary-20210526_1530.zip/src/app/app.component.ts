import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { OktaAuthService } from '@okta/okta-angular';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'JoggingDiary';
  isAuthenticated : boolean;

  constructor(public oktaAuth: OktaAuthService, private router: Router) {
    // Subscribe to authentication state changes
    this.oktaAuth.$authenticationState.subscribe(
      (isAuthenticated: boolean) => this.isAuthenticated = isAuthenticated
    );
  }

  async ngOnInit() {
    this.isAuthenticated = await this.oktaAuth.isAuthenticated();
  }

  login() {
    this.oktaAuth.signInWithRedirect({
      originalUri: '/home'
    });    
  }

  async logout() {
    console.log('logout');
    // Sign users out your application by ending their local session. 
    // This signs the user out of your app, but doesn't sign the user out of Okta.
    this.oktaAuth.tokenManager.clear();
    this.isAuthenticated = false;

    // // Will redirect to Okta to end the session then redirect back to the configured `postLogoutRedirectUri`
    // await this.oktaAuth.signOut();

    this.router.navigateByUrl('');
  }

  profile() {
    this.router.navigateByUrl('/profile');
  }

  stats() {
    this.router.navigateByUrl('/home');
  }
}
