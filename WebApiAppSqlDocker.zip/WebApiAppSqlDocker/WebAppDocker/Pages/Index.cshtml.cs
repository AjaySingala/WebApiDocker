﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace WebAppDocker.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        private readonly IConfiguration _config;

        public IndexModel(ILogger<IndexModel> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
        }

        public void OnGet()
        {
            //string apiUrl = "http://webapidocker:5000/version";
            var  apiUrl = _config.GetValue<string>("API_URL");
            ViewData["url"] = $"API URL: {apiUrl}";
            HttpClient httpClient = new HttpClient();
            var response = httpClient.GetAsync(apiUrl);  
            response.Result.EnsureSuccessStatusCode();
            var data = response.Result.Content.ReadAsStringAsync().Result;
            //JsonConvert.DeserializeObject<string>(data);
            
            //var data = apiUrl;
            
            ViewData["data"] = data.ToString();
        }
    }
}
