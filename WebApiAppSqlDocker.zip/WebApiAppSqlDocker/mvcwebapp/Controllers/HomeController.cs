﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using mvcwebapp.Models;

namespace mvcwebapp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IConfiguration _config;

        public HomeController(ILogger<HomeController> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
        }

        public IActionResult Index()
        {
            //string apiUrl = "http://webapidocker:5000/version";
            var  apiUrl = _config.GetValue<string>("API_URL");
            ViewData["url"] = $"API URL: {apiUrl}";
            HttpClient httpClient = new HttpClient();
            var response = httpClient.GetAsync(apiUrl);  
            response.Result.EnsureSuccessStatusCode();
            var data = response.Result.Content.ReadAsStringAsync().Result;
            //JsonConvert.DeserializeObject<string>(data);
            
            //var data = apiUrl;
            
            ViewData["data"] = data.ToString();

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
